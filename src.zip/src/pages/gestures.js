import React, { useState } from "react";
import Webcam from "react-webcam";
import styles from "./gesture.module.css";
import singleClickGif from "../assets/single_click.gif";
import hoverGif from "../assets/hover.gif";
import fourFingerGif from "../assets/4finger.gif";
import CameraFeed from './CameraFeed';

function Gestures() {
  const [selectedOptions, setSelectedOptions] = useState(Array(12).fill("Not Assigned"));

  const handleDropdownChange = (index, event) => {
    const updatedOptions = [...selectedOptions];
    updatedOptions[index] = event.target.value;
    setSelectedOptions(updatedOptions);
  };

  // Array of GIFs
  const gifs = [singleClickGif, hoverGif, fourFingerGif];

  // Function to divide the gifs array into rows
  const chunkArray = (array, chunkSize) => {
    const chunkedArray = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunkedArray.push(array.slice(i, i + chunkSize));
    }
    return chunkedArray;
  };

  // Divide the gifs into rows of three
  const gifRows = chunkArray(gifs, 3);

  return (
    <div className={styles.container}>
      <div className={`${styles.cameraContainer} ${styles.gestureContainer}`}>
        <h1>Camera Feed</h1>
        <CameraFeed />
      </div>
      <div className={styles.gestureContainer}>
        <h1>Gestures</h1>
        {/* Render GIFs in Rows */}
        {gifRows.map((row, rowIndex) => (
          <div key={rowIndex} className={styles.dropdownRow}>
            {row.map((gif, index) => (
              <div key={index} className={styles.dropdown}>
                {selectedOptions[rowIndex * 3 + index] === "Single Click" && (
                  <img src={singleClickGif} alt={`Single Click GIF`} style={{ width: "100px", height: "auto" }} />
                )}
                {selectedOptions[rowIndex * 3 + index] === "Hover" && (
                  <img src={hoverGif} alt={`Hover GIF`} style={{ width: "100px", height: "auto" }} />
                )}
                {selectedOptions[rowIndex * 3 + index] === "Open Keyboard" && (
                  <img src={fourFingerGif} alt={`Open Keyboard`} style={{ width: "100px", height: "auto" }} />
                )}
                {selectedOptions[rowIndex * 3 + index] === "Not Assigned" && (
                  <img src={hoverGif} alt={`Default GIF`} style={{ width: "100px", height: "auto" }} />
                )}
                <select value={selectedOptions[rowIndex * 3 + index]} onChange={(e) => handleDropdownChange(rowIndex * 3 + index, e)}>
                  <option value="Not Assigned">Not Assigned</option>
                  <option value="Single Click">Single Click</option>
                  <option value="Double Click">Double Click</option>
                  <option value="Right Click">Right Click</option>
                  <option value="Scroll Click">Scroll Click</option>
                  <option value="Hover">Hover</option>
                  <option value="Open Keyboard">Open Keyboard</option>
                  {/* Add more functionality options as needed */}
                </select>
              </div>
            ))}
          </div>
        ))}
        {/* Add your sign-up form or content here */}
      </div>
    </div>
  );
}

export default Gestures;

